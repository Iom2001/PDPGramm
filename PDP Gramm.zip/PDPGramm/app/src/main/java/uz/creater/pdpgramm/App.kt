package uz.creater.pdpgramm

class App {
}