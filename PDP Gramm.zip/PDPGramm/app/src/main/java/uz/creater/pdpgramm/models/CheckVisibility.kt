package uz.creater.pdpgramm.models

object CheckVisibility {
    var isChat = false
    var isGroup = false
}